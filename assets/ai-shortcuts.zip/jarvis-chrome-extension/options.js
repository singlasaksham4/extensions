// options.js
document.addEventListener('DOMContentLoaded', async () => {
  const apiKeyInput = document.getElementById('apiKey');
  const modelSelect = document.getElementById('model');
  const saveBtn = document.getElementById('saveBtn');

  chrome.storage.sync.get({ gemini_api_key: '', gemini_model: 'gemini-1.5-mini' }, (items) => {
    apiKeyInput.value = items.gemini_api_key || '';
    modelSelect.value = items.gemini_model || 'gemini-1.5-mini';
  });

  saveBtn.addEventListener('click', () => {
    const key = apiKeyInput.value.trim();
    const model = modelSelect.value;
    chrome.storage.sync.set({ gemini_api_key: key, gemini_model: model }, () => {
      alert('Saved');
    });
  });
});
