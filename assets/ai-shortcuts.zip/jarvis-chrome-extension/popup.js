// popup.js - Static list of keyboard shortcuts (No API Key Required)

const questionEl = document.getElementById('question');
const askBtn = document.getElementById('askBtn');
const summarizeBtn = document.getElementById('summarizeBtn'); // This button will be non-functional in this version
const micBtn = document.getElementById('micBtn');             // This button will be non-functional in this version
const voiceAnswerBtn = document.getElementById('voiceAnswerBtn'); // This button will be non-functional in this version
const answerEl = document.getElementById('answer');
const statusEl = document.getElementById('status');
const optionsBtn = document.getElementById('optionsBtn'); // This button will be non-functional in this version

// --- Static Data for Keyboard Shortcuts ---
// This is a pre-defined list of shortcuts. The extension will only be able to answer about these.
const keyboardShortcuts = {
  // General Shortcuts
  "copy": "Ctrl + C (or Cmd + C on Mac): Copies selected text or item.",
  "paste": "Ctrl + V (or Cmd + V on Mac): Pastes copied text or item.",
  "cut": "Ctrl + X (or Cmd + X on Mac): Cuts selected text or item.",
  "undo": "Ctrl + Z (or Cmd + Z on Mac): Undoes the last action.",
  "redo": "Ctrl + Y (or Cmd + Y on Mac) / Ctrl + Shift + Z (on Mac): Redoes the last undone action.",
  "save": "Ctrl + S (or Cmd + S on Mac): Saves the current document or file.",
  "new file": "Ctrl + N (or Cmd + N on Mac): Creates a new file or document.",
  "open file": "Ctrl + O (or Cmd + O on Mac): Opens an existing file.",
  "select all": "Ctrl + A (or Cmd + A on Mac): Selects all content.",
  "bold": "Ctrl + B (or Cmd + B on Mac): Applies bold formatting to selected text.",
  "italic": "Ctrl + I (or Cmd + I on Mac): Applies italic formatting to selected text.",
  "underline": "Ctrl + U (or Cmd + U on Mac): Applies underline formatting to selected text.",

  // Windows Specific Shortcuts
  "file explorer": "Win + E: Opens File Explorer.",
  "show desktop": "Win + D: Minimizes all windows to show the desktop.",
  "task view": "Win + Tab: Opens Task View, showing all open windows.",
  "lock computer": "Win + L: Locks your computer.",
  "task manager": "Ctrl + Shift + Esc: Opens Task Manager.",
  "switch apps": "Alt + Tab: Switches between currently open applications.",
  "close window": "Alt + F4: Closes the current application or window.",
  "switch windows": "Alt + Tab: Cycles through open windows.",

  // Google Chrome Shortcuts (Example)
  "new tab chrome": "Ctrl + T (or Cmd + T on Mac): Opens a new tab in Chrome.",
  "close tab chrome": "Ctrl + W (or Cmd + W on Mac): Closes the current tab in Chrome.",
  "reopen closed tab": "Ctrl + Shift + T (or Cmd + Shift + T on Mac): Reopens the last closed tab.",
  "new window chrome": "Ctrl + N (or Cmd + N on Mac): Opens a new Chrome window.",
  "incognito window": "Ctrl + Shift + N (or Cmd + Shift + N on Mac): Opens a new Incognito window.",
  "find chrome": "Ctrl + F (or Cmd + F on Mac): Opens the Find bar.",
  "history chrome": "Ctrl + H (or Cmd + H on Mac): Opens the Chrome History page.",
  "downloads chrome": "Ctrl + J (or Cmd + J on Mac): Opens the Chrome Downloads page."
};
// --- End Static Data ---


// Function to display status messages in the popup
function setStatus(text, isError = false) {
  statusEl.textContent = text;
  statusEl.style.color = isError ? 'red' : '#333';
}

// Function to search and display shortcut information
function searchShortcuts() {
  const query = questionEl.value.trim().toLowerCase();
  answerEl.textContent = ''; // Clear previous answer

  if (!query) {
    setStatus('Type a shortcut or keyword (e.g., "copy", "windows file explorer")', false);
    return;
  }

  let foundShortcut = null;

  // Direct match
  if (keyboardShortcuts[query]) {
    foundShortcut = keyboardShortcuts[query];
  } else {
    // Partial match (search for keywords within the stored shortcut descriptions)
    for (const key in keyboardShortcuts) {
      if (key.includes(query) || keyboardShortcuts[key].toLowerCase().includes(query)) {
        foundShortcut = keyboardShortcuts[key];
        break; // Found one, stop searching
      }
    }
  }

  if (foundShortcut) {
    answerEl.textContent = foundShortcut;
    setStatus('Shortcut found!');
  } else {
    answerEl.textContent = "I don't have information on that specific shortcut.";
    setStatus('Shortcut not found in my knowledge base.', true);
  }
}

// --- Event Listeners ---

// Ask AI button now acts as "Search Shortcut"
askBtn.addEventListener('click', searchShortcuts);

// These buttons are disabled/non-functional in this API-free version:
summarizeBtn.style.display = 'none'; // Hide the summarize button
micBtn.style.display = 'none';       // Hide the mic button
voiceAnswerBtn.style.display = 'none'; // Hide the voice answer button
optionsBtn.style.display = 'none';   // Hide the options button

// Remove event listeners for buttons that are now hidden or non-functional
// (Though since they are hidden, their listeners won't be called anyway)

// Initial status message
setStatus('Type a computer shortcut keyword (e.g., "copy", "Win+E")');

// Add event listener for Enter key to trigger search
questionEl.addEventListener('keypress', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault(); // Prevent default form submission
    searchShortcuts();
  }
});